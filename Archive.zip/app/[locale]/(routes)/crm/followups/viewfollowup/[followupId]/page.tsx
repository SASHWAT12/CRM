import moment from "moment";

import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

import { TeamConversations } from "./components/team-conversation";
import { getCrMTask } from "@/actions/crm/followups/get-followup";

type TaskPageProps = {
  params: Promise<{
    followupId: string;
  }>;
};

const CRMTaskPage = async (props: TaskPageProps) => {
  const params = await props.params;
  const { followupId } = params;
  // getCrMTask already fetches CRM-scoped comments via the Prisma relation
  // on crm_Accounts_Tasks — do not call the Projects-module getTaskComments
  // from here, that's a cross-module boundary violation.
  const task: any = await getCrMTask(followupId);
  const comments = task?.comments ?? [];

  return (
    <div className="flex flex-col md:flex-row w-full px-2 space-x-2 ">
      <div className="flex flex-col w-full md:w-2/3">
        <h4 className="scroll-m-20 text-xl font-semibold tracking-tight py-5">
          Followup details
        </h4>
        <div className="w-full border rounded-lg mb-5">
          {/*          <pre>
            <code>{JSON.stringify(task, null, 2)}</code>
          </pre> */}
          <table className="min-w-full text-sm">
            <thead>
              <tr>
                <th className="py-2 px-4 border-b font-semibold">
                  <span className="flex justify-start">Property</span>
                </th>
                <th className="py-2 px-4 border-b font-semibold">
                  <span className="flex justify-start">Value</span>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="py-2 px-4 border-b">ID</td>
                <td className="py-2 px-4 border-b">{task.id}</td>
              </tr>
              <tr>
                <td className="py-2 px-4 border-b">Date created</td>
                <td className="py-2 px-4 border-b">
                  {moment(task.createdAt).format("YYYY-MM-DD")}
                </td>
              </tr>
              <tr>
                <td className="py-2 px-4 border-b">Date due</td>
                <td className="py-2 px-4 border-b">
                  {moment(task.dueDateAt).format("YYYY-MM-DD")}
                </td>
              </tr>
              <tr>
                <td className="py-2 px-4 border-b">Date modified</td>
                <td className="py-2 px-4 border-b">
                  {moment(task.lastEditedAt).format("YYYY-MM-DD")}
                </td>
              </tr>
              <tr>
                <td className="py-2 px-4 border-b">Priority</td>
                <td className="py-2 px-4 border-b">
                  <Badge
                    variant={
                      task.priority === "high" ? `destructive` : `outline`
                    }
                  >
                    {task.priority}
                  </Badge>
                </td>
              </tr>
              <tr>
                <td className="py-2 px-4 border-b">Title</td>
                <td className="py-2 px-4 border-b">{task.title}</td>
              </tr>
              <tr>
                <td className="py-2 px-4 border-b">Content</td>
                <td className="py-2 px-4 border-b">{task.content}</td>
              </tr>
              <tr>
                <td className="py-2 px-4 border-b">Assigned to</td>
                <td className="py-2 px-4 border-b">
                  {task.assigned_user?.name || "Not assigned"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="w-full md:w-1/3">
        <TeamConversations data={comments} taskId={task.id} />
      </div>
    </div>
  );
};

export default CRMTaskPage;
