"use client";

import Link from "next/link";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

import { columns } from "../products/table-components/columns";
import { ProductsDataTable } from "../products/table-components/data-table";
import CreateProductForm from "../products/_forms/create-product";
import { ImportProductsDialog } from "../products/components/ImportProductsDialog";

import type { crm_ProductCategories } from "@prisma/client";

interface ProductsViewProps {
  data: any[];
  categories: crm_ProductCategories[];
}

const ProductsView = ({ data, categories }: ProductsViewProps) => {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between">
          <CardTitle>
            <Link href="/crm/products" className="hover:underline">
              Treatment Catalog
            </Link>
          </CardTitle>

          <div className="flex space-x-2">
            <ImportProductsDialog />
            <CreateProductForm
              categories={categories}
            />
          </div>
        </div>
        <Separator />
      </CardHeader>
      <CardContent>
        {!data || data.length === 0 ? (
          "No treatments found. Create your first treatment to get started."
        ) : (
          <ProductsDataTable data={data} columns={columns} />
        )}
      </CardContent>
    </Card>
  );
};

export default ProductsView;
