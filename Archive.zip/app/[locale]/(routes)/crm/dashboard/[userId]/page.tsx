import { getSession } from "@/lib/auth-server";
import { redirect } from "next/navigation";
import React from "react";
import Container from "../../../components/ui/Container";
import { getAccountsTasks } from "@/actions/crm/account/get-tasks";
import { getUserCRMFollowups } from "@/actions/crm/followups/get-user-followups";

const UserCRMDashboard = async () => {
  const session = await getSession();

  if (!session) {
    redirect("/auth/signin");
  }

  const task = await getUserCRMFollowups(session.user.id);

  return (
    <div>
      <Container
        title={`${session.user.name} | CRM Dashboard (in-progress) `}
        description="Your sales data in one place"
      >
        <div className="grid grid-cols-2 w-full ">
          <div className="">Calls overview</div>
          <div className="">
            <h1>Followups in Accounts</h1>
            <pre>{JSON.stringify(task, null, 2)}</pre>
          </div>
          <div className="">Meetings overview</div>
          <div className="">
            <h1></h1>
          </div>
          <div className="">Leads overview</div>
          <div className="">
            <h1></h1>
          </div>
        </div>
      </Container>
    </div>
  );
};

export default UserCRMDashboard;
