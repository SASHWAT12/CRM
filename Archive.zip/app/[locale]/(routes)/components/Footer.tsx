import getNextVersion from "@/actions/system/get-next-version";
import Link from "next/link";
import { version } from "@/package.json";


const Footer = async () => {
  const nextVersion = await getNextVersion();
  //console.log(nextVersion, "nextVersion");
  return (
    <footer className="flex flex-row h-8 justify-end items-center w-full text-xs text-muted-foreground p-5">
      <div className="hidden md:flex pr-5">
        <Link href="/">
          <h1 className="text-muted-foreground hover:text-foreground transition-colors">
            {process.env.NEXT_PUBLIC_APP_NAME} - v{version}
          </h1>
        </Link>
      </div>
      <div className="hidden md:flex space-x-2 pr-2">
        powered by Next.js
        <span className="bg-black dark:bg-white rounded-md text-white dark:text-black px-1 mx-1">
          {nextVersion.substring(1, 7) || process.env.NEXT_PUBLIC_NEXT_VERSION}
        </span>
        +
        <Link href={"https://ui.shadcn.com/"}>
          <span className="rounded-md mr-2 hover:text-foreground transition-colors">
            shadcnUI
          </span>
        </Link>{" "}
        hosted by:
        <span className="text-bold underline hover:text-foreground transition-colors">
          <Link href="https://www.vercel.com">Vercel</Link>
        </span>
      </div>
    </footer>
  );
};

export default Footer;
