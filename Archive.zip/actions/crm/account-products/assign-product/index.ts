"use server";
import { prismadb } from "@/lib/prisma";
import {
  requireAuthenticated,
  assertCanWriteAccount,
  AuthenticationError,
  AuthorizationError,
} from "@/lib/authz";
import { AssignProduct } from "./schema";
import { InputType, ReturnType } from "./types";
import { createSafeAction } from "@/lib/create-safe-action";
import { writeAuditLog } from "@/lib/audit-log";
import { revalidatePath } from "next/cache";

const handler = async (data: InputType): Promise<ReturnType> => {
  const { accountId, productId, quantity, custom_price, status, start_date, end_date, renewal_date, notes } = data;

  let user;
  try {
    user = await requireAuthenticated();
  } catch (e) {
    if (e instanceof AuthenticationError) return { error: "Unauthorized" };
    throw e;
  }

  try {
    await assertCanWriteAccount(user, accountId);
  } catch (e) {
    if (e instanceof AuthorizationError) return { error: "Forbidden" };
    throw e;
  }

  const userId = user.id;

  try {
    const product = await prismadb.crm_Products.findUnique({ where: { id: productId } });
    if (!product || product.deletedAt) {
      return { error: "Product not found" };
    }
    if (product.status !== "ACTIVE") {
      return { error: "Only active products can be assigned to accounts" };
    }

    const existingAssignment = await prismadb.crm_AccountProducts.findFirst({
      where: { accountId, productId, status: { in: ["ACTIVE", "PENDING"] } },
    });
    if (existingAssignment) {
      return { error: "This product is already assigned to this account with an active or pending status" };
    }

    if (end_date && end_date <= start_date) {
      return { error: "End date must be after start date" };
    }
    if (renewal_date && renewal_date <= start_date) {
      return { error: "Renewal date must be after start date" };
    }

    const assignment = await prismadb.crm_AccountProducts.create({
      data: {
        accountId, productId, quantity,
        custom_price: custom_price ? parseFloat(custom_price) : undefined,
        status: status || "ACTIVE",
        start_date,
        end_date: end_date || undefined,
        renewal_date: renewal_date || undefined,
        notes: notes || undefined,
        createdBy: userId,
        updatedBy: userId,
      },
    });

    await writeAuditLog({ entityType: "account_product", entityId: assignment.id, action: "created", changes: null, userId });

    revalidatePath("/[locale]/(routes)/crm/accounts/[accountId]", "page");
    revalidatePath("/[locale]/(routes)/crm/products/[productId]", "page");
    return { data: { id: assignment.id } };
  } catch (error) {
    console.log("[ASSIGN_PRODUCT]", error);
    return { error: "Failed to assign product to account" };
  }
};

export const assignProduct = createSafeAction(AssignProduct, handler);
