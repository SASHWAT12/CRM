"use server";
import { prismadb } from "@/lib/prisma";
import {
  generateEmbedding,
  toVectorLiteral,
} from "@/inngest/lib/embedding-utils";
import { requireAuthenticated, AuthenticationError } from "@/lib/authz";
import { getReportScope } from "@/lib/authz/scopes/report-scope";

export interface SearchResult {
  id: string;
  title: string;
  subtitle: string;
  url: string;
  score: number;
  matchType: "keyword" | "semantic" | "both";
}

export interface UnifiedSearchResults {
  accounts: SearchResult[];
  contacts: SearchResult[];
  leads: SearchResult[];
  tasks: SearchResult[];
  users: SearchResult[];
  documents: SearchResult[];
}

function mergeResults(
  keywordIds: Set<string>,
  semanticMap: Map<string, number>,
  allRecords: { id: string; title: string; subtitle: string; url: string }[]
): SearchResult[] {
  const results: SearchResult[] = allRecords.map((r) => {
    const inKeyword = keywordIds.has(r.id);
    const semanticScore = semanticMap.get(r.id) ?? 0;
    const score = 0.5 * (inKeyword ? 1.0 : 0) + 0.5 * semanticScore;
    const matchType: SearchResult["matchType"] =
      inKeyword && semanticScore > 0 ? "both" : inKeyword ? "keyword" : "semantic";
    return { ...r, score, matchType };
  });
  return results.sort((a, b) => b.score - a.score).slice(0, 10);
}

export async function unifiedSearch(
  query: string,
  locale: string = "en"
): Promise<UnifiedSearchResults | { error: string }> {
  let user;
  try {
    user = await requireAuthenticated();
  } catch (e) {
    if (e instanceof AuthenticationError) return { error: "Unauthorized" };
    throw e;
  }
  if (!query || query.trim().length < 2)
    return { error: "Query must be at least 2 characters" };

  const scope = getReportScope(user);

  // Generate embedding — fall back to keyword-only on failure (silent)
  let queryVec: string | null = null;
  try {
    const embedding = await generateEmbedding(query.trim());
    queryVec = toVectorLiteral(embedding);
  } catch (e) {
    console.warn("[UNIFIED_SEARCH] embedding failed, falling back to keyword-only", e);
  }

  const noSemantic = Promise.resolve([] as { id: string; similarity: number }[]);

  try {
    const [
      kwAccounts,
      kwContacts,
      kwLeads,
      kwTasks,
      kwUsers,
      kwDocuments,
      semAccounts,
      semContacts,
      semLeads,
      semDocuments,
      semDocChunks,
    ] = await Promise.all([
      prismadb.crm_Accounts.findMany({
        where: {
          deletedAt: null,
          AND: [
            scope.account,
            {
              OR: [
                { name: { contains: query, mode: "insensitive" } },
                { description: { contains: query, mode: "insensitive" } },
                { email: { contains: query, mode: "insensitive" } },
              ],
            },
          ],
        },
        take: 10,
        select: { id: true, name: true, email: true },
      }),
      prismadb.crm_Contacts.findMany({
        where: {
          deletedAt: null,
          AND: [
            scope.contact,
            {
              OR: [
                { first_name: { contains: query, mode: "insensitive" } },
                { last_name: { contains: query, mode: "insensitive" } },
                { email: { contains: query, mode: "insensitive" } },
              ],
            },
          ],
        },
        take: 10,
        select: { id: true, first_name: true, last_name: true, email: true },
      }),
      prismadb.crm_Leads.findMany({
        where: {
          deletedAt: null,
          AND: [
            scope.lead,
            {
              OR: [
                { firstName: { contains: query, mode: "insensitive" } },
                { lastName: { contains: query, mode: "insensitive" } },
                { company: { contains: query, mode: "insensitive" } },
                { email: { contains: query, mode: "insensitive" } },
              ],
            },
          ],
        },
        take: 10,
        select: { id: true, firstName: true, lastName: true, company: true, email: true },
      }),

      prismadb.tasks.findMany({
        where: {
          AND: [
            scope.task,
            {
              OR: [
                { title: { contains: query, mode: "insensitive" } },
                { content: { contains: query, mode: "insensitive" } },
              ],
            },
          ],
        },
        take: 10,
        select: { id: true, title: true, taskStatus: true },
      }),
      scope.allowUserDirectory
        ? prismadb.users.findMany({
            where: {
              OR: [
                { name: { contains: query, mode: "insensitive" } },
                { email: { contains: query, mode: "insensitive" } },
                { username: { contains: query, mode: "insensitive" } },
              ],
            },
            take: 10,
            select: { id: true, name: true, email: true },
          })
        : Promise.resolve([] as { id: string; name: string | null; email: string | null }[]),
      prismadb.documents.findMany({
        where: {
          parent_document_id: null,
          OR: [
            { document_name: { contains: query, mode: "insensitive" } },
            { summary: { contains: query, mode: "insensitive" } },
            { description: { contains: query, mode: "insensitive" } },
          ],
        },
        take: 10,
        select: {
          id: true,
          document_name: true,
          summary: true,
          document_system_type: true,
          accounts: { select: { account: { select: { name: true } } }, take: 1 },
        },
      }),
      queryVec
        ? prismadb.$queryRaw<{ id: string; similarity: number }[]>`
            SELECT a.id, 1 - (e.embedding <=> ${queryVec}::vector) AS similarity
            FROM "crm_Accounts" a
            LEFT JOIN "crm_Embeddings_Accounts" e ON e.account_id = a.id
            WHERE e.embedding IS NOT NULL
            ORDER BY e.embedding <=> ${queryVec}::vector
            LIMIT 10`
        : noSemantic,
      queryVec
        ? prismadb.$queryRaw<{ id: string; similarity: number }[]>`
            SELECT c.id, 1 - (e.embedding <=> ${queryVec}::vector) AS similarity
            FROM "crm_Contacts" c
            LEFT JOIN "crm_Embeddings_Contacts" e ON e.contact_id = c.id
            WHERE e.embedding IS NOT NULL
            ORDER BY e.embedding <=> ${queryVec}::vector
            LIMIT 10`
        : noSemantic,
      queryVec
        ? prismadb.$queryRaw<{ id: string; similarity: number }[]>`
            SELECT l.id, 1 - (e.embedding <=> ${queryVec}::vector) AS similarity
            FROM "crm_Leads" l
            LEFT JOIN "crm_Embeddings_Leads" e ON e.lead_id = l.id
            WHERE e.embedding IS NOT NULL
            ORDER BY e.embedding <=> ${queryVec}::vector
            LIMIT 10`
        : noSemantic,
      queryVec
        ? prismadb.$queryRaw<{ id: string; similarity: number }[]>`
            SELECT d.id, 1 - (e.embedding <=> ${queryVec}::vector) AS similarity
            FROM "Documents" d
            LEFT JOIN "crm_Embeddings_Documents" e ON e.document_id = d.id
            WHERE e.embedding IS NOT NULL AND d."parent_document_id" IS NULL
            ORDER BY e.embedding <=> ${queryVec}::vector
            LIMIT 10`
        : noSemantic,
      queryVec
        ? prismadb.$queryRaw<{ id: string; similarity: number }[]>`
            SELECT DISTINCT c."document_id" AS id,
                   MAX(1 - (c.embedding <=> ${queryVec}::vector)) AS similarity
            FROM "crm_Document_Chunks" c
            JOIN "Documents" d ON d.id = c."document_id"
            WHERE d."parent_document_id" IS NULL
            GROUP BY c."document_id"
            ORDER BY similarity DESC
            LIMIT 10`
        : noSemantic,
    ]);

    const semMap = (rows: { id: string; similarity: number }[]) =>
      new Map(rows.map((r) => [r.id, Number(r.similarity)]));

    const kwAccountIds = new Set(kwAccounts.map((r) => r.id));
    const kwContactIds = new Set(kwContacts.map((r) => r.id));
    const kwLeadIds = new Set(kwLeads.map((r) => r.id));

    const [extraAccounts, extraContacts, extraLeads] =
      await Promise.all([
        prismadb.crm_Accounts.findMany({
          where: {
            deletedAt: null,
            id: { in: semAccounts.map((r) => r.id).filter((id) => !kwAccountIds.has(id)) },
            AND: [scope.account],
          },
          select: { id: true, name: true, email: true },
        }),
        prismadb.crm_Contacts.findMany({
          where: {
            deletedAt: null,
            id: { in: semContacts.map((r) => r.id).filter((id) => !kwContactIds.has(id)) },
            AND: [scope.contact],
          },
          select: { id: true, first_name: true, last_name: true, email: true },
        }),
        prismadb.crm_Leads.findMany({
          where: {
            deletedAt: null,
            id: { in: semLeads.map((r) => r.id).filter((id) => !kwLeadIds.has(id)) },
            AND: [scope.lead],
          },
          select: { id: true, firstName: true, lastName: true, company: true, email: true },
        }),
      ]);

    const accounts = mergeResults(
      kwAccountIds,
      semMap(semAccounts),
      [...kwAccounts, ...extraAccounts].map((r) => ({
        id: r.id,
        title: r.name,
        subtitle: r.email ?? "",
        url: `/${locale}/crm/accounts/${r.id}`,
      }))
    );

    const contacts = mergeResults(
      kwContactIds,
      semMap(semContacts),
      [...kwContacts, ...extraContacts].map((r) => ({
        id: r.id,
        title: `${r.first_name ?? ""} ${r.last_name ?? ""}`.trim(),
        subtitle: r.email ?? "",
        url: `/${locale}/crm/patients/${r.id}`,
      }))
    );

    const leads = mergeResults(
      kwLeadIds,
      semMap(semLeads),
      [...kwLeads, ...extraLeads].map((r) => ({
        id: r.id,
        title:
          r.firstName || r.lastName
            ? `${r.firstName ?? ""} ${r.lastName ?? ""}`.trim()
            : (r.company ?? "Unknown Lead"),
        subtitle: r.email ?? r.company ?? "",
        url: `/${locale}/crm/leads/${r.id}`,
      }))
    );



    const tasks: SearchResult[] = kwTasks.map((r) => ({
      id: r.id,
      title: r.title,
      subtitle: r.taskStatus ?? "",
      url: `/${locale}/tasks/${r.id}`,
      score: 0.5,
      matchType: "keyword",
    }));

    const users: SearchResult[] = kwUsers.map((r) => ({
      id: r.id,
      title: r.name ?? r.email ?? "Unknown User",
      subtitle: r.email ?? "",
      url: `/${locale}/settings/users/${r.id}`,
      score: 0.5,
      matchType: "keyword",
    }));

    // Merge chunk semantic results into document semantic results
    const allSemDocs = [...semDocuments];
    for (const chunk of semDocChunks) {
      const existing = allSemDocs.find((d) => d.id === chunk.id);
      if (existing) {
        existing.similarity = Math.max(existing.similarity, chunk.similarity);
      } else {
        allSemDocs.push(chunk);
      }
    }

    const kwDocumentIds = new Set(kwDocuments.map((r) => r.id));

    const extraDocuments = queryVec
      ? await prismadb.documents.findMany({
          where: {
            parent_document_id: null,
            id: { in: allSemDocs.map((r) => r.id).filter((id) => !kwDocumentIds.has(id)) },
          },
          select: {
            id: true,
            document_name: true,
            summary: true,
            document_system_type: true,
            accounts: { select: { account: { select: { name: true } } }, take: 1 },
          },
        })
      : [];

    const documents = mergeResults(
      kwDocumentIds,
      semMap(allSemDocs),
      [...kwDocuments, ...extraDocuments].map((r) => ({
        id: r.id,
        title: r.document_name,
        subtitle: r.summary ?? r.accounts?.[0]?.account?.name ?? "",
        url: `/${locale}/documents?highlight=${r.id}`,
      }))
    );

    return { accounts, contacts, leads, tasks, users, documents };
  } catch (error) {
    console.error("[UNIFIED_SEARCH]", error);
    return { error: "Search failed" };
  }
}
